//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DBoglSAz.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-JiRtYUCG.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-JiRtYUCG.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BIeAzofT.js"]
	}
} });
//#endregion
export { tsrStartManifest };
